import React from "react"
import Header from "./Header.jsx"
import 
{
    Link
} from "react-router-dom";


class Home extends React.Component
{
    render()
    {
        return <div className="ui placeholder segment">

            <div className="ui stackable two column center aligned grid">
                <div className="ui vertical divider"></div>
                <div className="middle aligned row">
                    <div className="column">

                        <div className="ui icon header">
                            <i className="world icon"></i>
                            <div className="ui content">Method 1</div>

                        </div>
                        <div className="item">In this example, UI project calls github API directly. There is NO backend API</div>
                        &nbsp;
                        <div className="field">
                            <div className="ui search">
                                <div className="ui icon input">
                                    <div className="extra content">
                                        <div className="ui two buttons">
                                            <Link to="/method1">
                                                <div className="ui green button">View</div>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                                <div className="results"></div>
                            </div>
                        </div>
                    </div>
                    <div className="column">
                        <div className="ui icon header">
                            <i className="world icon"></i>
                            Method 2
                        </div>
                        <div className="item">In this example, UI project calls Hapi API. There is A backend API</div>
                        &nbsp;
                        <div className="field">
                            <div className="ui search">
                                <div className="ui icon input">
                                    <div className="extra content">
                                        <div className="ui two buttons">
                                            <Link to="/method2">
                                                <div className="ui red button">View</div>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                                <div className="results"></div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div >
    }
}
export default Home;