import React from "react"
import 
{
  BrowserRouter, Routes, Route
} from "react-router-dom";
import Method1 from "./Method1";
import Method2 from "./Method2";
import Home from "./Home";

class App extends React.Component  
{
  render()
  {
    return (
      <div>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route index element={<Home />} />
            <Route path="/method1" element={<Method1 />} />
            <Route path="/method2" element={<Method2 />} />
          </Routes>
        </BrowserRouter>
      </div>


    );
  }
}

export default App;
