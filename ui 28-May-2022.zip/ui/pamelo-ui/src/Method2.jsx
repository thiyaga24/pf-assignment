import React from "react"

import Header from "./Header";

import Pagination from '@mui/material/Pagination';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

class Method2 extends React.Component
{
    constructor()
    {
        super();
        this.state = {
            isLoading: false,
            totalcount: 0, data: { page: [] }, //Data will be an object {"0":[], "1":[], "3": [] }
            error: { open: false, msg: "Error Occurred" },
            pagination: {
                perPage: 10,
                currentPage: 1, //Index 1 based Page Numbers
            }
        };
    }

    /**
     * Function is to get Data from Git and Setting State
     * @param {*} gitpageNo 
     * @param {*} ourPageNumber 
     * @param {*} errmsg 
     * @returns 
     */
    async getRepos(ourPageNumber, errmsg = "")
    {
        let status = {
            isSuccess: false,
            errmsg: ""
        }

        let results = [];

        const url = `http://localhost:2500/gitrepos?pageno=${ourPageNumber}`
        let response, json;
        try
        {
            response = await fetch(url);//TODO : Set & Handle Timeout
            json = await response.json();
        }
        catch (ex)
        {
            status.isSuccess = false;
            status.errmsg = ex.message + ". Did you already execute the API Project at localhost:2500 ?";
            return status;
        }

        if (json?.status === "success" && json?.data?.length)
            results = json.data;

        else 
        {
            //error response from API
            status.isSuccess = false;
            status.errmsg = json.errortext;
            return status;
        }

        this.setState({
            data: { page: results },
            totalcount: json.totalcount
        })


        status.isSuccess = true;
        status.errmsg = "";
        return status;
    }


    /**
     * Event to handle Page number changes when user clicks pagenumbers in UI
     * @param {*} event 
     * @param {*} value 
     */
    handleChange = async (event, value) =>
    {
        this.setState({ isLoading: true });
        const status = await this.getRepos(value);
        this.setState({ isLoading: false });

        if (status.isSuccess)
        {
            //Hey, Succhess response from git or from our state
            let paginate = this.state.pagination;
            paginate.currentPage = value;
            this.setState({ pagination: paginate });
        }
        else 
        {
            //failure     from git
            this.showToast(status.errmsg);
        }
    };

    showToast = (text) =>
    {
        this.setState(
            { error: { open: true, msg: text } });

    }

    /**
     * Handle Toast Close functionality, We just need to reset the state back to original
     * @param {*} event 
     * @param {*} reason 
     * @returns 
     */
    handleClose = (event, reason) =>
    {
        if (reason === 'clickaway')
        {
            return;
        }

        this.setState(
            { error: { open: false } });
    };


    async componentDidMount()
    {
        // Initially we render, Page 1 from github always 
        this.setState({ isLoading: true });
        const status = await this.getRepos(1);
        this.setState({ isLoading: false });

        if (!status.isSuccess)
        {
            //failure     from git
            this.showToast(status.errmsg);
        }
    }

    render()
    {
        let totalCount = this.state.totalcount;
        let currentpage = this.state.data.page;



        if (this.state.isLoading)
            return <div className="ui container">
                <Header descr="This method calls http://localhost:2500/gitrepos API and get results from API"></Header>
                <table className="ui celled table">
                    <thead>
                        <tr><th>Repo Name</th>
                            <th>Description</th>
                            <th>stars</th>
                            <th>Git Link</th>
                            <th>Forks</th>
                            <th>Open Issues</th>
                        </tr></thead>
                </table>

                <div className="ui">
                    <div className="ui active inverted dimmer">
                        <div className="ui text loader">Loading</div>
                    </div>
                    <p></p>
                </div>
            </div>
        else if (currentpage)
            return <div className="ui container">
                <Header descr="This method calls http://localhost:2500/gitrepos API and get results from API"></Header>
                <table className="ui celled table">
                    <thead>
                        <tr><th>Repo Name</th>
                            <th>Description</th>
                            <th>stars</th>
                            <th>Git Link</th>
                            <th>Forks</th>
                            <th>Open Issues</th>
                        </tr></thead>
                    <tbody>
                        {currentpage.map(repo => (
                            <tr key={repo.id}>
                                <td data-label="Repo Name">{repo.full_name}</td>
                                <td data-label="Description">{repo.description}</td>
                                <td data-label="stars">{repo.stargazers_count}</td>
                                <td data-label="Git Link"><a href={repo.html_url}>Link</a></td>
                                <td data-label="Forks">{repo.forks}</td>
                                <td data-label="Open Issues">{repo.open_issues}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <Pagination count={Math.ceil(totalCount / this.state.pagination.perPage)} page={this.state.pagination.currentPage} onChange={this.handleChange} color="primary" size="large" shape="rounded" />

                <Snackbar open={this.state.error.open} autoHideDuration={6000} onClose={this.handleClose} anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}>
                    <Alert onClose={this.handleClose} severity="error" sx={{ width: '100%' }}>
                        {this.state.error.msg}
                    </Alert>
                </Snackbar>

                <br />
                <br />
                <br />
            </div>
    }
}
export default Method2;