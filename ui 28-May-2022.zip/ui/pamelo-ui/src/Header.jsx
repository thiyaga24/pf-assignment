
import React from "react"

class Header extends React.Component
{
    render()
    {
        return <div className="ui text"><br /><br /> <h1 className="ui dividing header">Nodejs Repositories</h1>
            <p className="ui text">{this.props.descr}</p>
        </div >

    }
}

export default Header;