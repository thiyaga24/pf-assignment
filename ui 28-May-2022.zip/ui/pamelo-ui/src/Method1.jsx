import React from "react"

import Header from "./Header";

import Pagination from '@mui/material/Pagination';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

class Method1 extends React.Component
{
    constructor()
    {
        super();
        this.state = {
            totalcount: 0, data: { page: [] }, //Data will be an object {"0":[], "1":[], "3": [] }
            error: { open: false, msg: "Error Occurred" },
            pagination: {
                perPage: 10,
                currentPage: 1, //Index 1 based Page Numbers
            }
        }; //page is pagenumber Key.

    }

    /**
     * Function is to get GitURL for the given Page Number  parameter
     * @param {*} pageNo 
     * @returns 
     */
    getURL = (pageNo) =>
    {
        if (!pageNo) pageNo = 1; //Default page if pageNo is missing

        return `https://api.github.com/search/repositories?q=nodejs&page=${pageNo}`
    }


    /**
     * Function is to get Data from Git and Setting State
     * @param {*} gitpageNo 
     * @param {*} ourPageNumber 
     * @param {*} errmsg 
     * @returns 
     */
    async getRepos(gitpageNo, ourPageNumber, errmsg = "")
    {
        let status = {
            isSuccess: false,
            errmsg: ""
        }

        if (isNaN(gitpageNo)) return status;
        let results = [];

        //check if its in our state
        if (!this.state.data[ourPageNumber.toString()])
        {

            let response = await fetch(this.getURL(gitpageNo));//TODO : Set & Handle Timeout
            let json = await response.json();

            if (json?.items?.length)
                results = json.items;
            else 
            {
                //error response from Git
                status.isSuccess = false;
                status.errmsg = json.message;

                return status;
            }


            this.setState({
                totalcount: json.total_count
            });


            //split by 10
            //example : We get 25th page from Git. Git jas 30 items per page.
            //so, We need 10 per page.so we are going to save in state as 25th, 26, 27th pages.
            let list = [...results];
            let currentPageCounter = (gitpageNo * 3) - 2;
            while (list.length)
            {
                let newlist = list.splice(0, 10);

                let localdata = this.state.data;
                localdata[currentPageCounter.toString()] = newlist;
                this.setState({ data: localdata });
                currentPageCounter++;
            }
        }

        //just trigger state so that, ourpagenumber will be rendered
        this.state.pagination.currentPage = ourPageNumber;

        status.isSuccess = true;
        status.errmsg = "";
        return status;
    }

    /**
     * Pass Our Table Page number and get GitPageNumber
     * @param {*} pageNo 
     */
    getGitPageNumber = (pageNo, perPage) =>
    {
        //our page number 5 means, git is returning  30 items per call. so we need to return 2 here.
        let n = Math.ceil((pageNo * perPage) / 30)
        return n; //git returns 30 results per page

    }

    /**
     * Event to handle Page number changes when user clicks pagenumbers in UI
     * @param {*} event 
     * @param {*} value 
     */
    handleChange = async (event, value) =>
    {

        let gitPageNo = this.getGitPageNumber(value, this.state.pagination.perPage);
        let error = "";
        const status = await this.getRepos(gitPageNo, value, error);

        if (status.isSuccess)
        {
            //Hey, Succhess response from git or from our state
            let paginate = this.state.pagination;
            paginate.currentPage = value;
            this.setState({ pagination: paginate });
        }
        else 
        {
            //failure     from git
            this.showToast(status.errmsg);
        }
    };

    showToast = (text) =>
    {
        this.setState(
            { error: { open: true, msg: text } });

    }

    /**
     * Handle Toast Close functionality, We just need to reset the state back to original
     * @param {*} event 
     * @param {*} reason 
     * @returns 
     */
    handleClose = (event, reason) =>
    {
        if (reason === 'clickaway')
        {
            return;
        }

        this.setState(
            { error: { open: false } });
    };


    async componentDidMount()
    {
        // Initially we render, Page 1 from github always 
        const status = await this.getRepos(this.getGitPageNumber(1, this.state.pagination.perPage), 1);

        if (!status.isSuccess)
        {
            //failure     from git
            this.showToast(status.errmsg);
        }
    }

    render()
    {
        let totalCount = this.state.totalcount;

        let currentpageNo = this.state.pagination.currentPage;
        let currentpage = this.state.data[this.state.pagination.currentPage.toString()];



        if (!currentpage)
            return <div className="ui container">
                <Header descr="This method directly calls GitHub API and handles all paging in client browser itself"></Header>
                <table className="ui celled table">
                    <thead>
                        <tr><th>Repo Name</th>
                            <th>Description</th>
                            <th>stars</th>
                            <th>Git Link</th>
                            <th>Forks</th>
                            <th>Open Issues</th>
                        </tr></thead>
                </table>

                <div className="ui">
                    <div className="ui active inverted dimmer">
                        <div className="ui text loader">Loading</div>
                    </div>
                    <p></p>
                </div>
            </div>
        else if (currentpage)
            return <div className="ui container">
                <Header descr="This method directly calls GitHub API and handles all paging in client browser itself"></Header>
                <table className="ui celled table">
                    <thead>
                        <tr><th>Repo Name</th>
                            <th>Description</th>
                            <th>stars</th>
                            <th>Git Link</th>
                            <th>Forks</th>
                            <th>Open Issues</th>
                        </tr></thead>
                    <tbody>
                        {currentpage.map(repo => (
                            <tr key={repo.id}>
                                <td data-label="Repo Name">{repo.full_name}</td>
                                <td data-label="Description">{repo.description}</td>
                                <td data-label="stars">{repo.stargazers_count}</td>
                                <td data-label="Git Link"><a href={repo.html_url}>Link</a></td>
                                <td data-label="Forks">{repo.forks}</td>
                                <td data-label="Open Issues">{repo.open_issues}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <Pagination count={Math.ceil(totalCount / this.state.pagination.perPage)} page={this.state.pagination.currentPage} onChange={this.handleChange} color="primary" size="large" shape="rounded" />

                <Snackbar open={this.state.error.open} autoHideDuration={4000} onClose={this.handleClose} anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}>
                    <Alert onClose={this.handleClose} severity="error" sx={{ width: '100%' }}>
                        {this.state.error.msg}
                    </Alert>
                </Snackbar>

                <br />
                <br />
                <br />
            </div>
    }
}
export default Method1;