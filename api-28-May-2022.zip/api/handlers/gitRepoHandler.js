import fetch from "node-fetch";


var state = { data: {} }; //act as in-memory cache
const perPage = 10; //We have to display 10 per page.

export const getRepoData = async (pageNumber) =>
{

    try
    {
        let status = await getRepos(pageNumber);
        if (status.isSuccess)
            return [state.data[pageNumber.toString()], state.totalcount]
        else throw new Error(status.errmsg)
    }
    catch (ex)
    {
        throw ex;
    }

}


/**
 * Function is to get GitURL for the given Page Number  parameter
 * @param {*} pageNo 
 * @returns 
 */
const getURL = (pageNo) =>
{
    if (!pageNo) pageNo = 1; //Default page if pageNo is missing

    return `https://api.github.com/search/repositories?q=nodejs&page=${pageNo}`
}

/**
 * Pass Our Table Page number and get GitPageNumber
 * @param {*} pageNo 
 */
const getGitPageNumber = (pageNo, perPage) =>
{
    //our page number 5 means, git is returning  30 items per call. so we need to return 2 here.
    let n = Math.ceil((pageNo * perPage) / 30)
    return n; //git returns 30 results per page

}

/**
 * Function is to get Data from Git and Setting State
 * @param {*} gitpageNo 
 * @param {*} pageNumber 
 * @param {*} errmsg 
 * @returns 
 */
const getRepos = async (pageNumber) =>
{

    let gitPageNo = getGitPageNumber(pageNumber, perPage);

    let status = {
        isSuccess: false,
        errmsg: "Missing page number"
    }

    if (isNaN(gitPageNo)) return status;
    let results = [];

    //check if its in our state
    if (!state?.data[pageNumber.toString()])
    {

        let response = await fetch(getURL(gitPageNo));//TODO : Set & Handle Timeout
        let json = await response.json();

        if (json?.items?.length)
            results = json.items;
        else 
        {
            //error response from Git
            status.isSuccess = false;
            status.errmsg = json.message;

            return status;
        }


        state["totalcount"] = json.total_count

        //split by 10
        //example : We get 25th page from Git. Git jas 30 items per page.
        //so, We need 10 per page.so we are going to save in state as 25th, 26, 27th pages.
        let list = [...results];
        let currentPageCounter = (gitPageNo * 3) - 2;
        while (list.length)
        {
            let newlist = list.splice(0, 10);

            let localdata = state.data;
            localdata[currentPageCounter.toString()] = newlist;
            state["data"] = localdata;
            currentPageCounter++;
        }
    }

    //just trigger state so that, ourpagenumber will be rendered
    status.isSuccess = true;
    status.errmsg = "";
    return status;
}


