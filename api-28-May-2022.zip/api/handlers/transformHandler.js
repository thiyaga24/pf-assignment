/**
 * Transform given JSON Obj to required format (Parent-child hierarchy).
 * @param {*} inputJson 
 * @returns Formatted JSON with rearranged children
 */
export const transformJSON = (inputJson) =>
{
    try
    {
        //Current input is key value pair, we would need array of nodes to process further
        let nodes = flattenNodes(inputJson);

        //find Parent Node.
        let parents = nodes.filter(node => node.parent_id === null);

        //find and attaching each parent with the child. Parents array going to modified
        attachChildren(parents, nodes);

        return parents;
    }
    catch (ex)
    {
        throw ex;
    }

}


/**
 * recursively find all children of each parent and attach it to their parent.
 * @param {List of Parent Nodes. This array will be modified} parents 
 * @param {All Nodes} nodes 
 * @returns Nothing
 */
const attachChildren = (parents, nodes) =>
{
    if (!parents || parents.length === 0) return [];
    for (let parent of parents)
    {
        //Is it really a valid parent  obj ?
        if (parent)
        {
            let children = nodes.filter(node => node.parent_id === parent.id);
            parent.children = children;
            attachChildren(children, nodes);
        }
    }
}

/**
 * The input json is key - Value Pair. we have to make it as array. so other operations will be easy.
 * @param {*} input 
 * @returns 
 */
export const flattenNodes = (input) =>
{
    //validating input json , if input not valid, return empty array
    if (!input) return [];

    let nodes = [];

    for (let key in input)
    {
        if (input[key] && input[key].length > 0) 
        {
            nodes.push(...input[key]);//flatten array and push to nodes variable.
        }
    }

    return nodes;
}

/**
 * Validate the user input and returns an array if any errors
 * @param {*} input 
 */
export const validateInput = (input) =>
{
    let errors = new Set([]);

    let nodes = flattenNodes(input);
    for (let node of nodes)
    {
        if (node.id === undefined) errors.add("node(s) is missing id field");
        if (node.parent_id === undefined) errors.add("node(s) is missing parent_id field");
    }

    return errors;

}

