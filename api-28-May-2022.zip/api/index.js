'use strict';
import * as Hapi from '@hapi/hapi';
import dotenv from "dotenv";
import * as  TransfromHandler from './handlers/transformHandler.js';
import * as GitRepoHandler from './handlers/gitRepoHandler.js';

//Hapi.server for Unit testing
export var server;

/**
 * Hapi API Server being initialised here 
 */
const init = async () =>
{

    server = Hapi.server({
        port: process.env.PORT,
        host: 'localhost'
    });

    addRoutes(server);
    await server.start();
    console.log('Server running on %s', server.info.uri);
};

/**
 * Function to add Routes to Hapi Server
 * @param {Hapi Server} hapiServer  A HapiServer instance 
 */
const addRoutes = (hapiServer) =>
{
    hapiServer.route({
        method: 'GET',
        path: '/',
        handler: (request, h) =>
        {

            return 'Hello World!';
        }
    });

    hapiServer.route({
        method: 'POST',
        path: '/transform',
        handler: (request, h) =>
        {
            let resFormat = {
                data: [],
                status: "success",
                errortext: ""
            }
            try
            {
                let input = request.payload;

                // Validating input .
                let errors = TransfromHandler.validateInput(input);
                if (errors && errors.size > 0) throw new Error([...errors].join(';'));

                //ok to proceed, We have now clean input
                let res = TransfromHandler.transformJSON(input);
                resFormat.data = res
                resFormat.errortext = ""
                resFormat.status = "success"
                return resFormat;
            }
            catch (ex)
            {
                resFormat.errortext = ex.message;
                resFormat.status = "failed"
                return resFormat;
            }


        }
    });

    hapiServer.route({
        method: 'GET',
        path: '/gitrepos',
        config: {
            cors: {
                origin: ['*'],
                additionalHeaders: ['cache-control', 'x-requested-with']
            }
        },
        handler: async (request, h) =>
        {
            let resFormat = {
                data: [],
                status: "success",
                errortext: "",
                totalcount: 0
            }
            try
            {
                let pageno = request.query["pageno"];

                // Validating input .
                if (isNaN(pageno) || parseInt(pageno) <= 0) throw new Error("Invalid Page Number")

                //ok to proceed, We have now clean input
                let [res, totalcount] = await GitRepoHandler.getRepoData(parseInt(pageno));
                resFormat.data = res
                resFormat.errortext = ""
                resFormat.status = "success"
                resFormat.totalcount = totalcount;

                return resFormat;
            }
            catch (ex)
            {
                resFormat.errortext = ex.message;
                resFormat.status = "failed"
                return resFormat;
            }


        }
    });

}
process.on('unhandledRejection', (err) =>
{

    console.log(err);
    process.exit(1);
});

dotenv.config(); //Required for reading  Environment file variables  from .env file
init();
