import { expect } from "chai";
import * as  TransfromHandler from '../handlers/transformHandler.js';

describe("transformHandler Tests", function ()
{

    describe("flattenNodes Tests", function ()
    {

        it("Testing Empty object", function ()
        {
            let testInput1 = {}

            let res = TransfromHandler.flattenNodes(testInput1);
            expect(res).to.deep.equal([])
        });

        it("One element without Key", function ()
        {
            let testInput1 =
                [{
                    "id": 10,
                    "title": "House",
                    "level": 0,
                    "children": [],
                    "parent_id": null
                }]
                ;

            let res = TransfromHandler.flattenNodes(testInput1);
            expect(res).to.deep.equal([])
        });

    });




    describe("transformJSON Tests", function ()
    {

        it("Testing Empty object", function ()
        {
            let testInput1 = {}
            let res = TransfromHandler.transformJSON(testInput1);
            expect(res).to.deep.equal([])

        });

        it("One Node object", function ()
        {
            let testInput1 = {
                "0":
                    [{
                        "id": 10,
                        "title": "House",
                        "level": 0,
                        "children": [],
                        "parent_id": null
                    }],
            };
            let res = TransfromHandler.transformJSON(testInput1);
            expect(res.length).to.deep.equal(1)

        });


        it("a Parent Node But Without Key named 'id'", function ()
        {
            let testInput1 = {
                "0":
                    [{

                        "title": "House",
                        "level": 0,
                        "children": [],
                        "parent_id": null
                    }],
            };
            let res = TransfromHandler.transformJSON(testInput1);
            // console.log(res);
            expect(res.length).to.deep.equal(1)

        });

        it("No Parent Node. All Children", function ()
        {
            let testInput1 = {
                "0":
                    [{
                        "title": "House",
                        "level": 0,
                        "children": [],
                        "parent_id": 12
                    }],
            };
            let res = TransfromHandler.transformJSON(testInput1);
            // console.log(res);
            expect(res.length).to.deep.equal(0)

        });

        it("One Child & One Parent", function ()
        {
            let testInput1 = {
                "0":
                    [{
                        "id": 10,
                        "title": "House",
                        "level": 0,
                        "children": [],
                        "parent_id": 12
                    }],
                "1":
                    [{
                        "id": 12,
                        "title": "House",
                        "level": 0,
                        "children": [],
                        "parent_id": null
                    }],
            };
            let res = TransfromHandler.transformJSON(testInput1);


            //checks whether we have response with one top level node?
            expect(res.length).to.deep.equal(1);

            //checks whether we have response with one top level node is parent
            expect(res[0].parent_id).to.equal(null);

            //checks whether we have 1 children ?
            expect(res[0].children.length).to.equal(1);

            //checks whether we have correct  children ? ie., with the id equal to 10?
            expect(res[0].children[0].id).to.equal(10);
        });

    });

});



